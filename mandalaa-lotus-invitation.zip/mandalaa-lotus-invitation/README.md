# Mandalaa Lotus Wedding Invitation

A responsive, single-page bilingual (English/Sinhala) wedding invitation starter built with plain HTML, CSS and JavaScript.

## Project structure

- `index.html` — page content and sections
- `css/style.css` — ivory/gold theme, responsive layout, animations
- `js/main.js` — editable couple/event details and interactive features
- `images/gallery/` — add your gallery photos
- `audio/` — add your licensed background music MP3

## First edits

Open `js/main.js` and edit the `WEDDING` object near the top:

- `groom`, `bride`
- `dateISO` (ISO date/time including Sri Lanka offset `+05:30`)
- `displayDate`, `displayDateSinhala`
- `time`, `venue`, `address`, `mapUrl`
- `rsvpEndpoint` (leave blank until the Google Apps Script RSVP endpoint is configured)

The starter uses the wedding date 7 December 2026 and the names Mahesh and Dhanjani. Venue and time are placeholders and must be replaced with confirmed details.

## Add photos

Copy your photos into `images/gallery/` using these exact names:

- `photo-1.jpg`
- `photo-2.jpg`
- `photo-3.jpg`

You can change the filenames in the `data-image` attributes in `index.html`. Use compressed JPG or WebP images, ideally around 150–400 KB each.

## Add background music

Add a music file you own or are licensed to use at `audio/wedding-music.mp3`. Browsers require a visitor interaction before audio can start; the music button handles this.

## Google Maps

Replace `mapUrl` with the share link for your actual venue in `js/main.js`. Both the venue link and directions button use it.

## RSVP

The form is a front-end starter. It does not store responses until you deploy a Google Apps Script web app and paste its URL into `rsvpEndpoint`. Do not publish the invitation with the RSVP form until you have tested a real submission end-to-end. `no-cors` mode means the browser cannot verify the server response; test the Google Sheet directly.

## Run locally

Open `index.html` in a browser. For a more reliable local preview, run a static server from this folder, for example:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Publish with GitHub Pages

1. Create a GitHub repository and upload the contents of this folder.
2. In repository Settings → Pages, choose **Deploy from a branch**.
3. Select the `main` branch and `/ (root)` folder, then save.
4. Wait for the Pages URL to appear. Add a custom domain later if desired.

## Before publishing checklist

- [ ] Confirm event time and venue
- [ ] Replace map link with the venue pin
- [ ] Add and test all gallery photos
- [ ] Add licensed MP3 and test playback on mobile
- [ ] Connect RSVP to Google Sheets and test submissions
- [ ] Test Sinhala text on Android and iPhone
- [ ] Check the countdown timezone/date
- [ ] Test WhatsApp share and calendar download
- [ ] Review all wording and privacy of guest information
