/* EDIT YOUR INVITATION DETAILS IN THIS SECTION */
const WEDDING = {
  groom: 'Mahesh',
  bride: 'Dhanjani',
  // Sri Lanka local time. Replace with your confirmed ceremony time.
  dateISO: '2026-12-07T10:00:00+05:30',
  displayDate: 'Monday, 7 December 2026',
  displayDateSinhala: '2026 දෙසැම්බර් 07 සඳුදා',
  time: 'Time to be confirmed',
  venue: 'Wedding venue',
  address: 'Add your full wedding venue address here',
  mapUrl: 'https://maps.google.com/?q=Colombo,Sri+Lanka',
  // Optional: paste your deployed Google Apps Script Web App URL here.
  rsvpEndpoint: ''
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
let currentLanguage = 'en';

function applyWeddingDetails() {
  $('#groomName').textContent = WEDDING.groom;
  $('#brideName').textContent = WEDDING.bride;
  $('.couple-names').innerHTML = `<span>${WEDDING.groom}</span><b>&amp;</b><span>${WEDDING.bride}</span>`;
  $('.closing-names').innerHTML = `${WEDDING.groom} <i>&amp;</i> ${WEDDING.bride}`;
  $('#heroDate').textContent = '07 · 12 · 2026';
  $('#eventDate').textContent = WEDDING.displayDate;
  $('#eventTime').textContent = WEDDING.time;
  $('#venueName').textContent = WEDDING.venue;
  $('#venueAddress').textContent = WEDDING.address;
  $('#mapLink').href = WEDDING.mapUrl;
  $('#directionsButton').href = WEDDING.mapUrl;
  document.title = `${WEDDING.groom} & ${WEDDING.bride} | Wedding Invitation`;
}

function updateCountdown() {
  const target = new Date(WEDDING.dateISO).getTime();
  const remaining = target - Date.now();
  if (remaining <= 0) {
    $('#countdown').innerHTML = '<p class="section-note">The celebration day is here. Thank you for being part of our story.</p>';
    return;
  }
  const days = Math.floor(remaining / 86400000);
  const hours = Math.floor((remaining % 86400000) / 3600000);
  const minutes = Math.floor((remaining % 3600000) / 60000);
  const seconds = Math.floor((remaining % 60000) / 1000);
  $('#days').textContent = String(days).padStart(3, '0');
  $('#hours').textContent = String(hours).padStart(2, '0');
  $('#minutes').textContent = String(minutes).padStart(2, '0');
  $('#seconds').textContent = String(seconds).padStart(2, '0');
}

function setLanguage(language) {
  currentLanguage = language;
  document.body.classList.toggle('lang-si', language === 'si');
  document.documentElement.lang = language;
  $$('[data-en][data-si]').forEach((element) => {
    element.textContent = element.dataset[language];
  });
  $('#languageToggle').textContent = language === 'en' ? 'සිං / EN' : 'EN / සිං';
  $('#eventDate').textContent = language === 'si' ? WEDDING.displayDateSinhala : WEDDING.displayDate;
}

function revealSections() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  $$('.reveal').forEach((element) => observer.observe(element));
}

function addToCalendar() {
  const start = new Date(WEDDING.dateISO);
  // Default calendar duration is 6 hours; adjust if your event duration differs.
  const end = new Date(start.getTime() + 6 * 60 * 60 * 1000);
  const format = (date) => date.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const escapeICS = (text) => text.replace(/\\/g, '\\\\').replace(/,/g, '\\,').replace(/;/g, '\\;').replace(/\n/g, '\\n');
  const ics = [
    'BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Mahesh and Dhanjani//Wedding Invitation//EN','CALSCALE:GREGORIAN','BEGIN:VEVENT',
    `UID:${Date.now()}@wedding-invitation.local`, `DTSTAMP:${format(new Date())}`, `DTSTART:${format(start)}`, `DTEND:${format(end)}`,
    `SUMMARY:${escapeICS(`${WEDDING.groom} & ${WEDDING.bride} - Wedding`)}`,
    `LOCATION:${escapeICS(`${WEDDING.venue}, ${WEDDING.address}`)}`,
    `DESCRIPTION:${escapeICS('We look forward to celebrating with you.')}`,'END:VEVENT','END:VCALENDAR'
  ].join('\r\n');
  const blob = new Blob([ics], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a'); link.href = url; link.download = 'wedding-invitation.ics'; link.click();
  URL.revokeObjectURL(url);
}

function setupGallery() {
  $$('.gallery-photo').forEach((button) => {
    const imagePath = button.dataset.image;
    const image = new Image();
    image.onload = () => { button.style.backgroundImage = `url("${imagePath}")`; button.classList.add('has-image'); };
    image.src = imagePath;
    button.addEventListener('click', () => {
      if (!button.classList.contains('has-image')) return;
      $('#lightboxImage').src = imagePath;
      $('#lightbox').classList.add('open');
      $('#lightbox').setAttribute('aria-hidden', 'false');
    });
  });
  const close = () => { $('#lightbox').classList.remove('open'); $('#lightbox').setAttribute('aria-hidden', 'true'); };
  $('#lightboxClose').addEventListener('click', close);
  $('#lightbox').addEventListener('click', (event) => { if (event.target.id === 'lightbox') close(); });
}

async function submitRSVP(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const status = $('#formStatus');
  const data = Object.fromEntries(new FormData(form).entries());
  data.submittedAt = new Date().toISOString();
  if (!WEDDING.rsvpEndpoint) {
    status.textContent = currentLanguage === 'si'
      ? 'RSVP සක්‍රිය කිරීමට js/main.js හි rsvpEndpoint සකසන්න. දැනට මෙම පෝරමය දත්ත යවන්නේ නැත.'
      : 'RSVP is not connected yet. Add your Google Apps Script Web App URL to rsvpEndpoint in js/main.js.';
    return;
  }
  status.textContent = currentLanguage === 'si' ? 'යවමින් පවතී...' : 'Sending...';
  try {
    await fetch(WEDDING.rsvpEndpoint, { method: 'POST', mode: 'no-cors', body: JSON.stringify(data), headers: { 'Content-Type': 'text/plain;charset=utf-8' } });
    status.textContent = currentLanguage === 'si' ? 'ඔබගේ පිළිතුර යවා ඇත. ස්තුතියි!' : 'Thank you! Your RSVP has been submitted.';
    form.reset();
  } catch (error) {
    status.textContent = currentLanguage === 'si' ? 'යැවීමට නොහැකි විය. කරුණාකර නැවත උත්සාහ කරන්න.' : 'Unable to submit. Please try again.';
  }
}

function setupMusic() {
  const audio = $('#backgroundMusic');
  const button = $('#musicToggle');
  button.addEventListener('click', async () => {
    if (audio.paused) {
      try { await audio.play(); button.classList.add('is-playing'); button.setAttribute('aria-label', 'Pause background music'); }
      catch { alert('Add your licensed MP3 file at audio/wedding-music.mp3, then try again.'); }
    } else {
      audio.pause(); button.classList.remove('is-playing'); button.setAttribute('aria-label', 'Play background music');
    }
  });
  audio.addEventListener('ended', () => button.classList.remove('is-playing'));
}

function shareOnWhatsApp() {
  const message = `You are warmly invited to celebrate the wedding of ${WEDDING.groom} & ${WEDDING.bride} on ${WEDDING.displayDate}. We would love to celebrate with you! ${window.location.href}`;
  window.open(`https://wa.me/?text=${encodeURIComponent(message)}`, '_blank', 'noopener');
}

function openInvitation() {
  $('#invitationContent').classList.remove('is-hidden');
  $('#welcome').scrollIntoView({ behavior: 'smooth' });
}

applyWeddingDetails();
updateCountdown();
setInterval(updateCountdown, 1000);
revealSections();
setupGallery();
setupMusic();
$('#languageToggle').addEventListener('click', () => setLanguage(currentLanguage === 'en' ? 'si' : 'en'));
$('#openInvitation').addEventListener('click', openInvitation);
$('#calendarButton').addEventListener('click', addToCalendar);
$('#shareButton').addEventListener('click', shareOnWhatsApp);
$('#rsvpForm').addEventListener('submit', submitRSVP);
